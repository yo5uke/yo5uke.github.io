# 行政区域データ（簡略版）

## 出典
本データは、国土交通省「国土数値情報 行政区域データ」（https://nlftp.mlit.go.jp/ksj/gml/datalist/KsjTmplt-N03-2024.html）をもとに、ポリゴンを簡略化（`ms_simplify`）して作成したものです。

## ライセンス
本データは、[CC BY 4.0](https://creativecommons.org/licenses/by/4.0/deed.ja)ライセンスのもとで提供されています。

## 加工内容
- ポリゴンの簡略化（`ms_simplify(keep = 0.05)`）

## 注意事項
- 本データは加工されており、正確性・完全性は保証されません。
- 利用にあたっては出典の明記をお願いいたします。
